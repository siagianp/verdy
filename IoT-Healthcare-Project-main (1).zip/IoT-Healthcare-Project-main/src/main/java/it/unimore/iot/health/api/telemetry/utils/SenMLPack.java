package it.unimore.iot.health.api.telemetry.utils;

import java.util.ArrayList;

/**
 *
 * List of SenMLRecord
 *
 * @author Marco Picone, Ph.D. - picone.m@gmail.com
 * @project coap-demo-smartobject
 * @created 27/10/2020 - 22:27
 */
public class SenMLPack extends ArrayList<SenMLRecord> {
}
