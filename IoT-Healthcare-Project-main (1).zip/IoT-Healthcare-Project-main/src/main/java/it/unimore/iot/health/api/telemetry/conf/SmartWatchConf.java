package it.unimore.iot.health.api.telemetry.conf;

public class SmartWatchConf {

    public static final String SMARTWATCH_ID = "test1";
    public static final String PRODUCER = "Apple";
    public static final String SOFTWARE_VERSION = "1.0.0-beta";

}
